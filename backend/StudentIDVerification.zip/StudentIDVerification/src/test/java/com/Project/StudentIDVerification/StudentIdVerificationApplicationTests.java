package com.Project.StudentIDVerification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentIdVerificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
